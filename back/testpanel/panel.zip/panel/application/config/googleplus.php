<?php defined('BASEPATH') OR exit('No direct script access allowed');

$config['googleplus']['redirect_uri'] = base_url() . 'login-with-google';
$config['googleplus']['api_key'] = '';
$config['googleplus']['scopes'] = array();

