<?php 


class Filter
{ 
	
	 function HtmlTag($tag)
	 {
		print_r($tag); 
		 
	 }
	
	
	
}

?>